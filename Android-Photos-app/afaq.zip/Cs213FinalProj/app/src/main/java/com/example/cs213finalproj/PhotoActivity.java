package com.example.cs213finalproj;

import android.app.Activity;

public class PhotoActivity extends Activity {
}
