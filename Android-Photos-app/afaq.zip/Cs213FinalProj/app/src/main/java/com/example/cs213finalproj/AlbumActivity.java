package com.example.cs213finalproj;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;

import model.Album;
import model.Photo;

public class AlbumActivity extends AppCompatActivity {

    RecyclerAdapter adapter;
    Button addPhoto;
    ArrayList<Uri> uri;
    GridView gridview;
    ArrayList<Photo> photos = new ArrayList<>();
    ArrayList<String> photosList = new ArrayList<>();
    ArrayAdapter<String>padapter;
    ListView lv_pList;
    int position;
    ArrayList<Album> albums;
    Album selectAlbum;
    ImageView display;
    Photo shownPhoto;
    Button openPhoto;
    Button deletePhoto;
    Photo currentPhoto;
    int delPosition;
    private static final int Read_Permission = 101;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.album_activity);
          loadData();
//                 Log.d("contians 1 ", imgUri.toString());
                for(Photo p : selectAlbum.getPhoto()){

                     Log.d("contains ", p.getFilePath());
                }
        uri = new ArrayList<>();

        gridview = (GridView) findViewById(R.id.gridView);
        openPhoto = findViewById(R.id.openPhoto);
        addPhoto = findViewById(R.id.addPhoto);
        deletePhoto = findViewById(R.id.deletePhoto);
        display = findViewById(R.id.display);
        adapter = new RecyclerAdapter(this, uri);
        gridview.setAdapter(adapter);
        //lv_pList = (ListView) findViewById(R.id.lv_pList);
        padapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,photosList);
//        lv_pList.setAdapter(padapter);

        Toast.makeText(getApplicationContext(),
                selectAlbum.getName(), Toast.LENGTH_LONG)
                .show();
        if(ContextCompat.checkSelfPermission(AlbumActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AlbumActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},Read_Permission);

        }

        for(int i = 0; i < selectAlbum.getPhoto().size();i++){

          uri.add(Uri.parse(selectAlbum.getPhoto().get(i).getFilePath()));
          adapter.notifyDataSetChanged();
        }

        addPhoto.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);


                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);
                saveData();
            }
        });

        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                position = i;
                String p = uri.get(position).toString();
                for(int m = 0; m < photos.size();m++){
                    if(photos.get(m).getFilePath().equals(p)){
                       shownPhoto = photos.get(m);
                    }
                }

                display.setImageURI(uri.get(position));
                adapter.setSelectedPosition(position);
                adapter.notifyDataSetChanged();
            }
        });


//        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                delPosition = i;
//                String delete = uri.get(position).toString();
//                for(int m = 0; m < photos.size();m++){
//                    if(photos.get(m).getFilePath().equals(delete)){
//                        shownPhoto = photos.get(m);
//                    }
//                }
//               deletePhoto.setOnClickListener(new View.OnClickListener() {
//                   @Override
//                   public void onClick(View view) {
//                       if(photos.size()>0){
//                       for(int place = 0; place < photos.size();place++){
//                    uri.remove(place);
//                    photos.remove(place);
//
//                       }
//
//
//
//
//                       }
//                   }
//               });
//            }
//        });
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1 && resultCode == Activity.RESULT_OK){
            if(data.getClipData() != null) {

                int x = data.getClipData().getItemCount();
                Calendar date = Calendar.getInstance();
                for (int i = 0; i < x; i++) {
                    if (!uri.contains((data.getClipData()).getItemAt(i).getUri())) {
                        uri.add((data.getClipData()).getItemAt(i).getUri());
                        Log.d("address", data.getClipData().getItemAt(i).getUri().toString());
                        //currentAlbum.addPhoto(new Photo("", data.getClipData().getItemAt(i).getUri().toString()));
                        String name = data.getClipData().toString();
                       Log.d("Name", name);
                     //   Photo photo= new Photo(name, date,data.getClipData().getItemAt(i).getUri().toString() );
                       // padapter.add(name);
                        //photos.add(photo);
                        //padapter.notifyDataSetChanged();


                    }
                }
            }
            else if(data.getData() != null) {
                Uri imgUri = data.getData();
                uri.add(imgUri);
                selectAlbum.addPhoto(new Photo("", imgUri.toString()));
//                  Log.d("contians 1 ", imgUri.toString());
//                for(Photo p : selectAlbum.getPhoto()){
//
//                     Log.d("contains ", p.getFilePath());
//                }
              //  Log.d("message", imgUri.toString());

            }



        }

        adapter.notifyDataSetChanged();
        saveData();

    }
    private void saveData() {

        for(int i = 0; i < albums.size(); i++){
            if(albums.get(i).albumName.equals(selectAlbum.albumName)){
                Log.d("Updated Album", albums.get(i).albumName);
                albums.set(i, selectAlbum);
            }
        }

        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(albums);
        editor.putString("album list", json);

        String json2 = gson.toJson(selectAlbum);
        editor.putString("selectedAlbum", json2);

          String json3 = gson.toJson(shownPhoto);
         editor.putString("selectedPhoto", json3);


        //  editor.putInt("selectedIndex", selected_idx);


        editor.apply();
    }


    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("album list", null);
        Type type = new TypeToken<ArrayList<Album>>() {}.getType();
        albums = gson.fromJson(json, type);

        if (albums == null) {
            albums = new ArrayList<>();
        }

        String json2 = sharedPreferences.getString("selectedAlbum", "");
        selectAlbum = gson.fromJson(json2, Album.class);

         String json3 = sharedPreferences.getString("selectedPhoto", "");
        shownPhoto = gson.fromJson(json3, Photo.class);

        // selected_idx  = sharedPreferences.getInt("selectedIndex", 0);


    }

    public Photo getDisplayedPhoto(){
        String p = uri.get(position).toString();
        for(int m = 0; m < photos.size();m++){
            if(photos.get(m).getFilePath().equals(p)){
                shownPhoto = photos.get(m);

            }
        }
        return null;
    }
    public void DeletePhoto(View view) {
        currentPhoto = getDisplayedPhoto();
        uri.remove(Uri.parse(currentPhoto.getFilePath()));
        adapter.notifyDataSetChanged();



//        selectAlbum.getPhoto().remove(currentPhoto);


    }



}

